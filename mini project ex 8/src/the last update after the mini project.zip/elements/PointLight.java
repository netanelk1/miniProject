package elements;

import primitives.*;

public class PointLight extends Light implements LightSource {

	protected Point3D position;
	protected double k_C;
	protected double k_L;
	protected double k_q;

	/**
	 * PointLight constructor
	 *  @param col
	 *   @param position
	 *    @param k_C
	 *     @param k_L
	 *      @param k_q
	 */
	public PointLight(Color col, Point3D Position, double k_C, double k_L, double k_q) {
		super(col);
		position = new Point3D(Position);
		this.k_C = k_C;
		this.k_L = k_L;
		this.k_q = k_q;
	}

	/**
	 * Getter for the position point
	 * @return position
	 */

	public Point3D getPosition() {
		return position;
	}

	
	/**
	 * find the Vector L by substruct the point minus the position
	 */
	
	@Override
	public Vector getL(Point3D P) {
		return (position.subtract(P)).normalization();
	}

	@Override
	public Vector getD(Point3D P) {
		return (getL(P));
	}

	/**
	 * find the intensity in specific point
	 * @return intensity
	 */
	@Override
	public Color getIntensity(Point3D P) {
		double distance = P.distance(position);
		double num = k_C + k_L * distance + k_q * distance * distance;
		Color intensity = getIntensity().reduce(num);
		return intensity;
	}

}
