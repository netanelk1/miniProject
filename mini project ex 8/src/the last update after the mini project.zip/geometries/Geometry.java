package geometries;
import java.util.List;
import java.util.Map;

import primitives.*;
public abstract class Geometry {
	
    protected Color emission;
	protected Material material;
    
	public Geometry(Color emission,Material material) {
		this.emission =emission;
		this.material=material;
	}

	public Geometry(Geometry geo)
	{
		this.emission=geo.emission;
		this.material=geo.material;
	}
	public Color getEmission() {
		return emission;
	}

	public Material getMaterail(){
		return material;
	}

	//*functions*//
	public abstract Vector get_normal(Point3D p);
	public abstract Map<Geometry,List<Point3D>> findIntersections(Ray y);
}
 
 //322981275
//314623364