package unittests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import geometries.*;
import primitives.*;
import renderer.ImageWriter;
import renderer.Render;
import scene.Scene;
import elements.*;

public class RenderTest {
	@Test
	public void basicRendering() {
		Scene scene = new Scene("test scene");
		scene.setCem(new Camera(new Point3D(0, 0, 0), new Vector(0, -1, 0), new Vector(0, 0, 1)));
		scene.setBackground(Color.BLACK);
		scene.setAmbientlight(new AmbientLight(Color.WHITE, 0.2));
		Geometries geometries = new Geometries();
		geometries.add(new Sphere(50, new Point3D(0, 0, 150), Color.BLACK, new Material(0, 0, 0,0,0)));

		geometries.add(new Triangle(new Point3D(100, 0, 149), new Point3D(0, 100, 149), new Point3D(100, 100, 149),
				new Color(java.awt.Color.GREEN), new Material(1, 0.8, 5,0,0)));

		geometries.add(new Triangle(new Point3D(100, 0, 149), new Point3D(0, -100, 149), new Point3D(100, -100, 149),
				new Color(java.awt.Color.BLUE), new Material(1, 0.8, 5,0,0)));

		geometries.add(new Triangle(new Point3D(-100, 0, 149), new Point3D(0, 100, 149), new Point3D(-100, 100, 149),
				new Color(java.awt.Color.RED), new Material(1, 0.8, 5,0,0)));

		geometries.add(new Triangle(new Point3D(-100, 0, 149), new Point3D(0, -100, 149), new Point3D(-100, -100, 149),
				Color.BLACK, new Material(1, 0.8, 5,0,0)));
		scene.setListofGeom(geometries);
		scene.setDistence(150);

		ImageWriter imageWriter = new ImageWriter("emission rendering", 500, 500, 500, 500);
		Render render = new Render(scene, imageWriter);

		render.renderImage();
		render.printGrid(50);
		render.getImagewriter().writeToimage();
	}

	@Test
	public void SpotLightTest() {
		Scene scene = new Scene("Test Scene3");
		scene.setCem(new Camera(new Point3D(0, 0, 0), new Vector(0, -1, 0), new Vector(0, 0, 1)));
		scene.setDistence(350);
		scene.setBackground(new Color());
		scene.setAmbientlight(new AmbientLight(Color.WHITE, 0));
		Geometries geometries = new Geometries();
		geometries.add(new Sphere(50, new Point3D(0, 0, 150), new Color(20,20,20), new Material(0.8, 0.7, 100,0,0)));
		List<LightSource> lights=new ArrayList<LightSource>();
		lights.add(new SpotLight(new Color(200, 200, 200),new Point3D(0,60, 100), 1, 0, 0,
				new Vector(0,-1,1)));
		scene.set_lights(lights);
		scene.setListofGeom(geometries);
		ImageWriter imageWriter = new ImageWriter("SpotLight", 500, 500, 500, 500);
		Render render = new Render(scene, imageWriter);

		render.renderImage();
		render.printGrid(50);
		render.getImagewriter().writeToimage();
	}

	@Test
	public void DirectionalLightTest() {
		Scene scene = new Scene("Test Scene3");
		scene.setCem(new Camera(new Point3D(0, 0, 0), new Vector(0, -1, 0), new Vector(0, 0, 1)));
		scene.setDistence(350);
		scene.setBackground(new Color(0, 0, 0));
		scene.setAmbientlight(new AmbientLight(new Color(255,255, 255),0.2));
		Geometries geometries = new Geometries();
		geometries.add(new Sphere(50, new Point3D(0, 0, 150), new Color(125, 92, 168), new Material(0.66, 0.9,20,0,0)));
		List<LightSource> lights=new ArrayList<LightSource> ();
		lights.add(new DirectionalLight(new Color(128, 128, 128), new Vector(-1, 1,1)));
		scene.set_lights(lights);
		scene.setListofGeom(geometries);
		ImageWriter imageWriter = new ImageWriter("first test", 500, 500, 500, 500);
		Render render = new Render(scene, imageWriter);
		render.renderImage();
		render.printGrid(50);
		render.getImagewriter().writeToimage();
	}

	@Test
	public void PointLightTest() {
		Scene scene = new Scene("Test Scene3");

		scene.setCem(new Camera(new Point3D(0, 0, 0), new Vector(0, -1, 0), new Vector(0, 0, 1)));
		scene.setDistence(350);
		scene.setBackground(new Color(0, 0, 0));
		scene.setAmbientlight(new AmbientLight(new Color(255, 255, 255), 0.2));
		Geometries geometries = new Geometries();
		geometries.add(new Sphere(50, new Point3D(0, 0, 150), new Color(0,0,128), new Material(0.8, 0.7,200,0,0)));
		List<LightSource> lights=new ArrayList<LightSource> ();
		lights.add(new PointLight(new Color(200,200,200),new Point3D(20, 30,90), 1, 0, 0));
		scene.set_lights(lights);
		scene.setListofGeom(geometries);
		ImageWriter imageWriter = new ImageWriter("PointLight Test", 500, 500, 500, 500);
		Render render = new Render(scene, imageWriter);

		render.renderImage();
		render.printGrid(50);
		render.getImagewriter().writeToimage();

	}
	@Test
	public void SpotLightTest3(){
		Scene scene=new Scene("SpotLight 3");
		scene.setCem(new Camera(new Point3D(0, 0, 0), new Vector(0, -1, 0), new Vector(0, 0, 1)));
		scene.setDistence(350);
		scene.setBackground(new Color(0, 0, 0));
		scene.setAmbientlight(new AmbientLight(new Color(255, 255, 255), 0.2));
		Geometries geometries = new Geometries();
		Triangle triangle1 = new Triangle(new Point3D(-250,-250,500),new Point3D(-250,250,500),new Point3D(250,-250,500),new Color(0,0,0),new Material(0.9, 0.8, 100,0,0));
	    Triangle triangle2 = new Triangle(new Point3D(250,250,500),new Point3D(-250,250,500),new Point3D(250,-250,500),new Color(0,0,0),new Material(0.9, 0.8, 100,0,0));
		geometries.add(triangle1);
		geometries.add(triangle2);
		scene.setListofGeom(geometries);
		List<LightSource> lights = new ArrayList<LightSource>();
		lights.add(new SpotLight(new Color(255,255,255),new Point3D(0,0,10), 1, 0, 0,new Vector(0,0,1)));
		scene.set_lights(lights);
		ImageWriter imageWriter = new ImageWriter("SpotLight 3", 500, 500, 500, 500);
		Render render = new Render(scene, imageWriter);
		render.renderImage();
		render.printGrid(50);
		render.getImagewriter().writeToimage();
	}
	@Test
	public void SpotLightTest2(){
		
		Scene scene = new Scene("SpotLight 2");
		scene.setCem(new Camera(new Point3D(0, 0, 0), new Vector(0, -1, 0), new Vector(0, 0, 1)));
		scene.setDistence(350);
		scene.setBackground(new Color(0, 0, 0));
		scene.setAmbientlight(new AmbientLight(new Color(255, 255, 255), 0.2));
		Geometries geometries = new Geometries();
		geometries.add(new Sphere(50, new Point3D(0, 0, 150), new Color(0,0,128), new Material(0.8, 0.7,200,0,0)));
		List<LightSource> lights=new ArrayList<LightSource> ();
		lights.add(new SpotLight(new Color(200,200,200),new Point3D(20, 30,90), 1, 0, 0,new Vector(0,-1,1)));
		scene.set_lights(lights);
		scene.setListofGeom(geometries);
		ImageWriter imageWriter = new ImageWriter("SpotLight 2", 500, 500, 500, 500);
		Render render = new Render(scene, imageWriter);

		render.renderImage();
		render.printGrid(50);
		render.getImagewriter().writeToimage();
	}
	
	@Test
	  public void shadowTest() {
	    Scene scene = new Scene("Test shadow");
	    scene.setCem(new Camera(new Point3D(0, 0, 0), new Vector(0, -1, 0), new Vector(0, 0, 1)));
	    scene.setDistence(120);
	    scene.setBackground(new Color(0,0,0));
	    Geometries geometries = new Geometries();
	    Sphere sphere = new Sphere( 50,new Point3D(0, 0, 150), new Color(241, 6, 151),new Material(0.9,0.8,300,0,0));
	    Triangle triangle1 = new Triangle(new Point3D(-250,-250,250),new Point3D(-250,250,250),new Point3D(250,-250,250),new Color(0,0,0),new Material(0.9, 0.8, 100,0,0));
	    Triangle triangle2 = new Triangle(new Point3D(250,250,250),new Point3D(-250,250,250),new Point3D(250,-250,250),new Color(0,0,0),new Material(0.9, 0.8, 100,0,0));
	    geometries.add(sphere);
	    geometries.add(triangle1);
	    geometries.add(triangle2);
	    scene.setListofGeom(geometries);
	    List<LightSource> lights = new ArrayList<LightSource>();
	    lights.add(new SpotLight( new Color(200,200,200) ,new Point3D(20,10,30), 1,0,0, new Vector(0,0,1)));
	    scene.set_lights(lights);
	    ImageWriter imageWriter = new ImageWriter("shadow test", 500, 500, 500, 500);
	    Render render = new Render(scene, imageWriter);
	    render.renderImage();
	    render.printGrid(50);
	    render.getImagewriter().writeToimage();
	    
	  }
	@Test
	public void recursiveTest(){
		Scene scene = new Scene("recursiveTest 1");
		scene.setDistence(300);
		scene.setBackground(new Color(0,0,0));
		scene.setAmbientlight(new AmbientLight(new Color(255,255,255),0.2));
		scene.setCem(new Camera(new Point3D(0, 0, 0), new Vector(0, 1, 0), new Vector(0, 0, -1)));
		Sphere sphere = new Sphere(500, new Point3D(0.0, 0.0, -1000), new Color(0, 0, 100),
				new Material(0.5, 0.3, 10, 0, 0.5));
		scene.addGeometry(sphere);
		
		Sphere sphere2 = new Sphere(250, new Point3D(0.0, 0.0, -1000), new Color(100, 20, 20),
				new Material(0.4, 0.4, 10, 0.5, 0));


		scene.addGeometry(sphere2);
		List<LightSource> lights = new ArrayList<LightSource>();
		lights.add(new SpotLight(new Color(255, 100, 100),new Point3D(-200, -200, -150), 0.1, 0.01, 0.0025,
				new Vector(2, 2, -3)));
		
		scene.set_lights(lights);
		ImageWriter imageWriter = new ImageWriter("Recursive Test", 500, 500, 500, 500);
		
		Render render = new Render(scene,imageWriter);
		render.renderImage();
		render.getImagewriter().writeToimage();
	
	}
	@Test
	public void recursiveTest2() {

		Scene scene = new Scene("recursive2");
		scene.setCem(new Camera(new Point3D(0, 0, 0), new Vector(0, 1, 0), new Vector(0, 0, -1)));
		scene.setDistence(300);
		scene.setBackground(new Color(0, 0, 0));
		scene.setAmbientlight(new AmbientLight(new Color(255,255,255),0.2));

		Sphere sphere = new Sphere(500, new Point3D(0.0, 0.0, -1000), new Color(0, 0, 100),
				new Material(0.5, 0.3, 10, 0, 0.5));

		scene.addGeometry(sphere);

		Sphere sphere2 = new Sphere(150, new Point3D(-550, -500, -1000), new Color(100, 20, 20),
				new Material(0.3, 0.4, 10, 0.5, 0));
		scene.addGeometry(sphere2);

		Triangle triangle = new Triangle(new Point3D(1500, -1500, -1500), new Point3D(-1500, 1500, -1500),
				new Point3D(200, 200, -375), new Color(20, 20, 20), new Material(0.4, 0.6, 10, 1, 0));

		Triangle triangle2 = new Triangle(new Point3D(1500, -1500, -1500), new Point3D(-1500, 1500, -1500),
				new Point3D(-1500, -1500, -1500), new Color(20, 20, 20), new Material(0.4, 0.6, 10, 0.5, 0));

		scene.addGeometry(triangle);
		scene.addGeometry(triangle2);

		List<LightSource> lights = new ArrayList<LightSource>();
		lights.add(new SpotLight(new Color(255, 100, 100),new Point3D(200, 200, -150), 0, 0.0001, 0.005,
				new Vector(-2, -2, -3)));
		scene.set_lights(lights);

		ImageWriter imageWriter = new ImageWriter("Recursive Test 2", 500, 500, 500, 500);

		Render render = new Render(scene, imageWriter);

		render.renderImage();
		render.getImagewriter().writeToimage();

	}
	@Test
	public void recursiveTest3() {

		Scene scene = new Scene("recursive3");
		scene.setCem(new Camera(new Point3D(0, 0, 0), new Vector(0, 1, 0), new Vector(0, 0, -1)));
		scene.setDistence(300);
		scene.setBackground(new Color(0, 0, 0));
		scene.setAmbientlight(new AmbientLight(new Color(255,255,255),0.2));
		
		Sphere sphere = new Sphere(300, new Point3D(0, 0, -1500), new Color(0, 0, 100), new Material(0.5, 0.3, 10, 0, 0.5));
		scene.addGeometry(sphere);

		Sphere sphere2 = new Sphere(150, new Point3D(0, 0, -1500), new Color(100, 20, 20), new Material(0.4, 0.6, 10, 0.5, 0));
		scene.addGeometry(sphere2);

		Triangle triangle = new Triangle(new Point3D(2000, -1000, -2000), new Point3D(-1000, 2000, -2000),
				new Point3D(700, 700, -875), new Color(20, 20, 20), new Material(0.5, 0.3, 10, 1, 0));

		Triangle triangle2 = new Triangle(new Point3D(2000, -1000, -2000), new Point3D(-1000, 2000, -2000),
				new Point3D(-1000, -1000, -2000), new Color(20, 20, 20), new Material(0.55, 0.25, 10, 0.5, 0));

		scene.addGeometry(triangle);
		
		scene.addGeometry(triangle2);


		List<LightSource> lights = new ArrayList<LightSource>();
		lights.add(new SpotLight(new Color(255, 100, 100),new Point3D(200, 200, -650), 0, 0.0001, 0.005,
				new Vector(-2, -2, -3)));
		scene.set_lights(lights);

		ImageWriter imageWriter = new ImageWriter("Recursive Test 3", 500, 500, 500, 500);

		Render render = new Render(scene, imageWriter);

		render.renderImage();
		render.getImagewriter().writeToimage();

	}
}
