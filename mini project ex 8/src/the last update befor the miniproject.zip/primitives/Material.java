package primitives;

public class Material {
	protected double  _Kd;
	protected double _Ks;
	protected int nShininess;
	protected double _Kr;
	protected double _Kt;
	
	
	 //*constructors*//
	public Material(double _Kd, double _Ks, int nShininess,double _Kr,double _Kt) {
		super();
		this._Kd = _Kd;
		this._Ks = _Ks;
		this.nShininess = nShininess;
		this._Kr=_Kr;
		this._Kt=_Kt;
		
	}
	
	
	public Material(Material material)
	{
		this._Kd=material._Kd;
		this._Ks=material._Ks;
		this.nShininess=material.nShininess;
		this._Kr=material._Kr;
		this._Kt=material._Kt;
	}
	
	
	/**getters setters*/
	public double get_Kd() {
		return _Kd;
	}
	
	public double get_Ks() {
		return _Ks;
	}
	
	public int getnShininess() {
		return nShininess;
	}


	public double get_Kr() {
		return _Kr;
	}



	public double get_Kt() {
		return _Kt;
	}


	
	
	

}
