package elements;

import primitives.*;

public class Camera {
	private Point3D p0;
	private Vector Vup;
	private Vector Vto;
	private Vector Vright;

	// *constructor*//
	public Camera(Point3D p, Vector Vu, Vector Vt) {
		p0 = new Point3D(p);
		if (!Coordinate.isZero(Vu.dotProduct(Vt)))
			throw new IllegalArgumentException("Non-orthogonal vectors for Camera!");
		Vup = new Vector(Vu).normalization();
		Vto = new Vector(Vt).normalization();
		Vright = Vu.crossProduct(Vt).normalization();
	}

	// *getters and setters*//

	public Point3D getP0() {
		return p0;
	}

	public Vector getVup() {
		return Vup;
	}

	public Vector getVto() {
		return Vto;
	}

	public Vector getVright() {
		return Vright;
	}

	// *constructing ray through pixel*//
	public Ray constructRayThroughPixel(int Nx, int Ny, int i, int j,
			double screenDistance, double screenWidth, double screenHeight) {
		double Ry = screenHeight / Ny;
		double Rx = screenWidth / Nx;
		Vector v = Vto.scalar(screenDistance);
		Point3D Pij = p0.add(v);
		double Xi = (i - (Nx / 2.0)) * Rx - (Rx / 2.0);
		if (Xi != 0.0)
			Pij = Pij.add(Vright.scalar(Xi));
		double Yj = (j - (Ny / 2.0)) * Ry - (Ry / 2.0);
		if (Yj != 0.0)
			Pij = Pij.add(Vup.scalar(-Yj));
		return new Ray(p0, p0.subtract(Pij));
	}
}