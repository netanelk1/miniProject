package elements;

import primitives.*;

public class SpotLight extends PointLight {

	private Vector direction;

	/**
	 * Getter for direction 
	 * @return direction
	 */
	public Vector getDirection() {
		return direction;
	}


	/**
	 * SpotLight constructor
	 * @param col
	 * @param position
	 * @param k_C
	 * @param k_L
	 * @param k_q
	 * @param direction
	 */
	public SpotLight(Color col, Point3D position, double k_C, double k_L, double k_q, Vector direction) {
		super(col, position, k_C, k_L, k_q);
		this.direction = new Vector(direction).normalization();
	}

	/**
	 * find the intensity of color in specific point
	 */
	@Override
	public Color getIntensity(Point3D P) {
		double ld = getL(P).dotProduct(direction);
		return ld > 0 ? super.getIntensity(P).scale(ld) : new Color();
	}

	/**
	 * find the direction of the source light
	 * @return direction
	 */
	@Override
	public Vector getD(Point3D p) {
		return direction;
	}

}
