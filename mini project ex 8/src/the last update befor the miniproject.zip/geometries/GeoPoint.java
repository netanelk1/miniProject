package geometries;
import primitives.*;

public class GeoPoint {
	public Geometry geometry;
	public Point3D point;
	
	
	
	public Geometry getGeometry() {
		return geometry;
	}
	
	
	public Point3D getPoint() {
		return point;
	}


	public GeoPoint(Geometry geometry, Point3D point) {
		
		this.geometry = geometry;
		this.point = point;
	}
	
	
	public GeoPoint(GeoPoint p)
	{
		this.geometry=p.geometry;
		this.point=p.point;
	}
	
	
	
	
}
