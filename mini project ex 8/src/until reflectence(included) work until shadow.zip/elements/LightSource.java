package elements;
import primitives.*;

public interface LightSource {
	/**
	 * find the intensity in specific point
	 * @param point
	 * @return
	 */
	public Color getIntensity(Point3D point);
	
	/**
	 * find the vector L for specific point
	 * @param point
	 * @return
	 */
	public Vector getL(Point3D point);
	
	
	/**
	 * find the vector D (direction ) in specific point
	 * @param Point
	 * @return
	 */
	public Vector getD(Point3D Point);

}
