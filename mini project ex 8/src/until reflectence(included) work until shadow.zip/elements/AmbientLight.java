package elements;

import primitives.*;

public class AmbientLight extends Light {
	private double k_a;
	private Color intensity;

	// *getters and setters*//

	public double getK_a() {
		return k_a;
	}

	// *constructors*//

	public AmbientLight(Color color, double k) {
		super(color);
		this.k_a = k;
		intensity = new Color(color).scale(k);
	}

	// get_intensity()
	@Override
	public Color getIntensity() {
		return new Color(intensity);
	}

}
