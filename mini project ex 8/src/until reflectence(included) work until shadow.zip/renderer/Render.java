package renderer;

import scene.*;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import elements.LightSource;
import primitives.*;
import geometries.*;

public class Render {
	private Scene scene;
	private ImageWriter imagewriter;

	// *constructor*//

	public Render(Scene scene, ImageWriter imagewriter) {
		this.scene = scene;
		this.imagewriter = imagewriter;
	}

	// *getters and setters*//

	public Scene getScene() {
		return scene;
	}

	public void setScene(Scene scene) {
		this.scene = scene;
	}

	public ImageWriter getImagewriter() {
		return imagewriter;
	}

	public void setImagewriter(ImageWriter imagewriter) {
		this.imagewriter = imagewriter;
	}

	// *functions*//

	public Map<Geometry, Point3D> getClosestPoint(Map<Geometry, List<Point3D>> intersectionPoints) {
		double min = Double.MAX_VALUE;
		Map<Geometry, Point3D> point = new HashMap<Geometry, Point3D>();
		for (Entry<Geometry, List<Point3D>> p : intersectionPoints.entrySet()) {
			Geometry key = p.getKey();
			for (Point3D poit : p.getValue()) {
				double d = poit.distance(scene.getCem().getP0());
				if (d < min) {
					min = d;
					point.clear();
					point.put(key, poit);
				}
			}
		}
		return point;
	}

	public Color calcColor(GeoPoint gp,Ray inRay,int level,double k) {
	/*	if(level==0 || Coordinate.ZERO.equals(k) || gp.geometry==null )
			return Color.BLACK;*/
		
		Color color = new Color(scene.getAmbientlight().getIntensity());
		color.add(gp.geometry.getEmission());
		
		Vector v=inRay.getDirection();
		Vector vec = (scene.getCem().getP0().subtract(gp.point)).normalization();
		Vector n =gp. geometry.get_normal(gp.point);
		int nShininiess = gp.geometry.getMaterail().getnShininess();
		double Kd = gp.geometry.getMaterail().get_Kd();
		double Ks = gp.geometry.getMaterail().get_Ks();
		
		for (LightSource lights : scene.get_lights()) {
			Vector L = lights.getL(gp.point).normalization();
			if ((n.dotProduct(L)) * (n.dotProduct(vec)) > 0) {
				//double o=occluded(L,gp);
				//if(!Coordinate.ZERO.equals(o * k)){
				//Color lightIntensity = (new Color(lights.getIntensity(gp.point))).scale(o);
				if(!occluded(L,gp)){
				Color lightIntensity = (new Color(lights.getIntensity(gp.point)));
				color.add(calcDiffusive(Kd, L, n, lightIntensity));
				color.add(calcSpecular(Ks, L, n, vec, nShininiess, lightIntensity));
				//}
				}
			}
		}
		
					/*
					// Recursive call for a reflected ray
					Ray reflectedRay = constructReflectedRay(n, gp.point, inRay);
					
					Map<Geometry, Point3D> reflec = new HashMap<Geometry, Point3D>();
					reflec.putAll(getClosestPoint(scene.getListofGeom().findIntersections(reflectedRay)));
					
					Geometry g = (Geometry) reflec.keySet().toArray()[0];
					Point3D p = (Point3D) reflec.values().toArray()[0];
					GeoPoint reflectedPoint=new GeoPoint(g,p);
					double kr = gp.geometry.getMaterail().get_Kr();
					Color reflectedLight = calcColor(reflectedPoint, reflectedRay, level - 1, k * kr).scale(kr);
					
					
					
					
					
					// Recursive call for a refracted ray
					Ray refractedRay = constructRefractedRay(gp.point, inRay);
					Map<Geometry, Point3D> refrec = new HashMap<Geometry, Point3D>();
					refrec.putAll(getClosestPoint(scene.getListofGeom().findIntersections(refractedRay)));
					Geometry g1 = (Geometry) refrec.keySet().toArray()[0];
					Point3D p1 = (Point3D) refrec.values().toArray()[0];
					GeoPoint refractedPoint=new GeoPoint(g1,p1);
					double kt = gp.geometry.getMaterail().get_Kt();
					Color refractedLight = calcColor(refractedPoint, refractedRay, level - 1, k * kt).scale(kt);
					return color.add(reflectedLight, refractedLight);
					*/
					
					
		return new Color(color);
	}

	
	private Color calcColor(GeoPoint gp,Ray r)
	{
		return calcColor(gp,r,10,1.0);
	}
	public void printGrid(int interval) { // assuming that interval is between the
										// lines of the grid
		for (int i = 0; i < imagewriter.getWidth(); i++) {
			for (int j = 0; j < imagewriter.getHeight(); j++) {
				if (i % interval == 0 || j % interval == 0) {
					imagewriter.writePixel(i, j, 255, 255, 255);
				}
			}
		}
	}

	public void renderImage() {
		for (int i = 0; i < imagewriter.getNx(); i++) {
			for (int j = 0; j < imagewriter.getNy(); j++) {

				Ray ray = scene.getCem().constructRayThroughPixel(imagewriter.getNx(), imagewriter.getNy(), i, j,
						scene.getDistence(), imagewriter.getWidth(), imagewriter.getHeight());
				Map<Geometry, List<Point3D>> intersectionsPoints = new HashMap<Geometry, List<Point3D>>();
				if (scene.getListofGeom().findIntersections(ray) == null) {
					imagewriter.writePixel(i, j, scene.getBackground().getColor());
				} else {
					intersectionsPoints.putAll(scene.getListofGeom().findIntersections(ray));
					Geometry geo = null;
					Point3D p = null;
					Map<Geometry, Point3D> ClosestPoint = getClosestPoint(intersectionsPoints);
					for (Entry<Geometry, Point3D> s : ClosestPoint.entrySet()) {
						geo = s.getKey();
						p = s.getValue();
					}
					GeoPoint gp=new GeoPoint(geo,p); 
					//System.out.println(p.toString());
					imagewriter.writePixel(i, j, calcColor(gp,ray).getColor());
				}
			}
		}
	}

	public Color calcDiffusive(double Kd, Vector L, Vector n, Color lightIntensity) {
		return lightIntensity.scale(Kd * Math.abs(L.dotProduct(n)));
	}

	public Color calcSpecular(double Ks, Vector L, Vector n, Vector v, int nShininiess, Color lightIntensity) {
		double w = -2 * (L.dotProduct(n));
		Vector r = L.add(n.scalar(w)).normalization();
		double vr = r.dotProduct(v);
		if (vr > 0)
			return Color.BLACK;
		return (lightIntensity.scale(Ks * Math.pow(Math.abs(r.dotProduct(v)), nShininiess)));

	}

	/*private Ray constructReflectedRay(Vector n, Point3D p, Ray inRay) {
		Vector v = inRay.getDirection();
		Vector w=n.scalar(2 * (v.dotProduct(n)));
		Vector r=w.subtract(v);
		return new Ray(p, r);
	}
	
	private Ray constructRefractedRay(Point3D p, Ray inRay) {
		Vector v = inRay.getDirection();
		return new Ray(p, v);
	}
	
	*/
	
	
	

/*	public double occluded(Vector L, GeoPoint gp)
	{
		Vector lightDirection = L.scalar(-1); // from point to light source
		Vector normal = gp.geometry.get_normal(gp.point);
		Vector epsVector = normal.scalar(normal.dotProduct(lightDirection) > 0 ? 2 : -2);
		Point3D geometryPoint =gp. point.add(epsVector);
		Ray lightRay = new Ray(geometryPoint, lightDirection);
	
		double shadowK=1;
		
		if(scene.getListofGeom().findIntersections(lightRay)==null)
		{
			return shadowK;
		}
		else{
		Map<Geometry, List<Point3D>> intersectionPoints =new HashMap<Geometry, List<Point3D>>();
		intersectionPoints.putAll(scene.getListofGeom().findIntersections(lightRay));
		for (Entry<Geometry, List<Point3D>> entry : intersectionPoints.entrySet()){
			shadowK *= entry.getKey().getMaterail().get_Kt();
		}
		
		return shadowK;
		}
	}

*/
	public boolean occluded(Vector L, GeoPoint gp)
	{
		Vector lightDirection = L.scalar(-1); // from point to light source
		Vector normal = gp.geometry.get_normal(gp.point);
		Vector epsVector = normal.scalar(normal.dotProduct(lightDirection) > 0 ? 2 : -2);
		Point3D geometryPoint =gp. point.add(epsVector);
		Ray lightRay = new Ray(geometryPoint, lightDirection);
		
		
		if(scene.getListofGeom().findIntersections(lightRay)==null)
		{
			return false;
		}
		else{
		return true;
		}
	}
}